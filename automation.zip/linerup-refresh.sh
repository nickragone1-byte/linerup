#!/usr/bin/env bash
# linerup-refresh.sh
# Runs MLB V10 + NBA V7 models hourly, pushes JSON to GitHub → Vercel
#
# MLB window:  9 AM – 3 PM PT  (predictions before first pitch, stops before games start)
# NBA window: 10 AM – 4 PM PT  (predictions before evening tip-offs)
# Both models pull fresh Vegas lines every run — no separate line refresh needed

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
LINERUP_DIR="$HOME/Desktop/linerup"
MLB_DEST="$LINERUP_DIR/public/data/mlb/predictions.json"
NBA_DEST="$LINERUP_DIR/public/data/nba/predictions.json"
LOG="$HOME/Library/Logs/linerup-refresh.log"
RSCRIPT="/usr/local/bin/Rscript"
MIN_SIZE=500   # minimum bytes for a valid JSON

# ── Logging helper ────────────────────────────────────────────────────────────
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"
}

# ── Current hour (Pacific) ────────────────────────────────────────────────────
HOUR=$(TZ="America/Los_Angeles" date +"%H")
TODAY=$(TZ="America/Los_Angeles" date +"%Y-%m-%d")

log "===== linerup-refresh START (hour=${HOUR} PT) ====="

# ── Track whether anything changed ───────────────────────────────────────────
CHANGES=0

# ════════════════════════════════════════════════════════════════════════════
#  MLB — run 9 AM through 3 PM PT
#  V10 pulls fresh lines every run, so every run captures line movement
# ════════════════════════════════════════════════════════════════════════════
if [ "$HOUR" -ge 9 ] && [ "$HOUR" -lt 16 ]; then
  log "--- MLB V10 run starting ---"
  cd "$LINERUP_DIR"

  if "$RSCRIPT" "$LINERUP_DIR/v10-mlb-playoff.R" >> "$LOG" 2>&1; then
    log "MLB R script completed"

    # Verify output
    if [ -f "$MLB_DEST" ]; then
      MLB_SIZE=$(wc -c < "$MLB_DEST" | tr -d ' ')
      if [ "$MLB_SIZE" -ge "$MIN_SIZE" ]; then
        log "MLB JSON verified: ${MLB_SIZE} bytes"
        CHANGES=1
      else
        log "WARNING: MLB JSON too small (${MLB_SIZE} bytes) — skipping commit"
      fi
    else
      log "WARNING: MLB JSON not found at $MLB_DEST"
    fi
  else
    log "ERROR: MLB R script failed — keeping existing JSON"
  fi
else
  log "SKIP: MLB window is 9 AM–3 PM PT (hour=${HOUR})"
fi

# ════════════════════════════════════════════════════════════════════════════
#  NBA — run 10 AM through 4 PM PT
#  V7 pulls fresh lines and injury data every run
# ════════════════════════════════════════════════════════════════════════════
if [ "$HOUR" -ge 10 ] && [ "$HOUR" -lt 17 ]; then
  log "--- NBA V7 run starting ---"
  cd "$LINERUP_DIR"

  if "$RSCRIPT" "$LINERUP_DIR/nba_v7_predictions.R" >> "$LOG" 2>&1; then
    log "NBA R script completed"

    # Verify output
    if [ -f "$NBA_DEST" ]; then
      NBA_SIZE=$(wc -c < "$NBA_DEST" | tr -d ' ')
      if [ "$NBA_SIZE" -ge "$MIN_SIZE" ]; then
        log "NBA JSON verified: ${NBA_SIZE} bytes"
        CHANGES=1
      else
        log "WARNING: NBA JSON too small (${NBA_SIZE} bytes) — skipping commit"
      fi
    else
      log "WARNING: NBA JSON not found at $NBA_DEST"
    fi
  else
    log "ERROR: NBA R script failed — keeping existing JSON"
  fi
else
  log "SKIP: NBA window is 10 AM–4 PM PT (hour=${HOUR})"
fi

# ════════════════════════════════════════════════════════════════════════════
#  Git commit + push if anything changed
# ════════════════════════════════════════════════════════════════════════════
if [ "$CHANGES" -eq 1 ]; then
  cd "$LINERUP_DIR"
  git add public/data/mlb/predictions.json public/data/nba/predictions.json

  if git diff --cached --quiet; then
    log "No changes to commit — predictions unchanged since last run"
  else
    COMMIT_MSG="auto: predictions update $(TZ='America/Los_Angeles' date +'%Y-%m-%d %H:%M') PT"
    git commit -m "$COMMIT_MSG"
    log "Committed: $COMMIT_MSG"
    git push
    log "Pushed to GitHub — Vercel deploy triggered"
  fi
else
  log "No successful runs — nothing to commit"
fi

log "===== linerup-refresh DONE ====="
